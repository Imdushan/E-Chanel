(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["xlsx"],[
/* 0 */,
/* 1 */
/*!********************!*\
  !*** fs (ignored) ***!
  \********************/
/*! no static exports found */
/***/ (function(module, exports) {

/* (ignored) */

/***/ })
]]);